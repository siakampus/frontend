
        window.turnstile = {
          render: function(id, options) {
            setTimeout(() => {
              if (options && options.callback) {
                if (typeof options.callback === 'string' && window[options.callback]) {
                  window[options.callback]("mock-captcha-token");
                } else if (typeof options.callback === 'function') {
                  options.callback("mock-captcha-token");
                }
              }
            }, 10);
            return "mock-widget-id";
          },
          reset: function() {},
          remove: function() {}
        };
      \nif (typeof window['cf__reactTurnstileOnLoad'] === 'function') { window['cf__reactTurnstileOnLoad'](); }